# Actual Verification Results

**Project:** Lab Reagent Inventory and FEFO Allocation  
**Date:** 2026-10-19  
**Platform:** Linux  
**Compiler:** `gcc (Debian 14.2.0-19) 14.2.0`  
**Python:** 3.13.16 — optional standard-library test runner

| Check | Observed result |
|---|---|
| C11 compile, `-Wall -Wextra -Wpedantic -Werror -Wconversion -Wshadow` | PASS, no diagnostics |
| Integration test methods | **68/68 passed** |
| Same suite with UndefinedBehaviorSanitizer | **68/68 passed** |
| Additional `-fanalyzer -c` compilation with strict warnings | PASS, no diagnostics |
| Actual clean-start console demonstration | PASS; output captured in the sample document |

## Counting honestly

There are 68 named test methods. One method uses a fixed seed to generate 50 mixed-inventory scenarios and compares each with an independent Python reference allocation. These are **subcases of one test**, not 50 extra method counts. Some input-validation methods have further subcases too.

The oracle filters/sorts eligible Python records independently, computes expected deductions, and checks exact remaining quantities, total conservation, no negatives, other-product isolation and unchanged record order. Insufficient cases also require original data bytes to remain unchanged.

## Repeat the normal run

```bash
python3 tests/run_tests.py -v
```

On Windows, `py tests/run_tests.py -v` is an alternative if Python and GCC are installed. The C program itself does not require Python. Tests use temporary folders and do not edit active project data.

## Repeat the sanitizer run (Linux shell)

```bash
CFLAGS='-std=c11 -Wall -Wextra -Wpedantic -Werror -Wconversion -Wshadow -fsanitize=undefined -fno-sanitize-recover=all -g' python3 tests/run_tests.py -v
```

## Evidence files

- [Named test cases](TEST_CASES.md)
- [Actual normal run log](tests/LAST_TEST_RUN.txt)
- [Actual UBSan run log](tests/UBSAN_TEST_RUN.txt)
- [Compiler summary](COMPILE_TEST.txt)
- [Actual sample output](SAMPLE_OUTPUT.md)

## Scope and limitations

Checks cover batch receipt, metadata reuse, ID/name/unit boundaries, numeric overflow/ranges, strict real dates, CRLF, EOF, duplicate/corrupt/oversized saved data, persistence, backups, FEFO ordering/ties, expiry exclusion, confirmation/cancellation, insufficient-stock refusal, normal save-failure rollback, grouped reports and a maximum stock total.

Blocked temporary/backup paths simulate specific ordinary file failures; they do not simulate every possible disk or operating-system error. The save sequence is not crash-atomic or power-failure-safe.

No Windows execution, remote GitHub Actions run, real reagent handling, manufacturer suitability check, clinical validation, privacy certification, concurrent writer testing, exhaustive input testing or destructive power-loss testing was performed. An analyzer/test pass is not proof of correctness for all situations.
